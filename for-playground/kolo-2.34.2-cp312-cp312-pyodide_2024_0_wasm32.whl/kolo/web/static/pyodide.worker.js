importScripts("https://cdn.jsdelivr.net/pyodide/v0.25.0/full/pyodide.js");

async function loadPyodideAndPackages() {
  self.pyodide = await loadPyodide();

  let mountDir = "/data";
  pyodide.FS.mkdir(mountDir);
  pyodide.FS.mount(pyodide.FS.filesystems.IDBFS, { root: "." }, mountDir);

  await new Promise((resolve, reject) => {
    pyodide.FS.syncfs(true, (err) => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });

  await self.pyodide.loadPackage(["micropip"]);

  // httpx from kolo requires ssl
  await self.pyodide.runPythonAsync(`
    import micropip
    print("installing django")
    await micropip.install('tzdata')
    await micropip.install('django')
    await micropip.install("sqlite3")
    await micropip.install("ssl")
    await micropip.install("https://kloppindustries.github.io/kolo-wheels/kolo-2.21.1+local-cp311-cp311-emscripten_3_1_46_wasm32.whl")
  `);
}

let pyodideReadyPromise = loadPyodideAndPackages().then(() => {
  self.postMessage({ ready: true });
});

self.onmessage = async (event) => {
  console.log("received msg", event);
  await pyodideReadyPromise;

  const { id, python, ...context } = event.data;

  for (const key of Object.keys(context)) {
    self[key] = context[key];
  }

  try {
    await self.pyodide.loadPackagesFromImports(python);

    const result = pyodide.runPython(python);

    // console.log("work3r result", result)

    self.pyodide.FS.syncfs(false, (err) => {
      self.postMessage({ result, id });
    });
  } catch (error) {
    console.log("error", error);
    self.postMessage({ error: error.message, id });
  }
};
