"""Streaming msgpack trace writer that splices pre-packed frame bytes in
place, without round-tripping them through Python dicts.

The profiler/monitoring backends store each captured frame as already-
serialized ``bytes`` (so ``sum(len(frame) for frame …)`` can drive subtree
flush byte accounting cheaply). When it's time to save — whether the root
trace or a flushed subtree — we need those frame bytes to land inside the
outer trace's ``threads.<tid>.frames`` array. Re-encoding every frame just
to pack the outer map would double the work for no reason and is
prohibitively expensive for 500MB+ flushed subtrees.

Instead, this module writes the outer map header and metadata fields
normally, then for each thread's ``frames`` key writes a msgpack array
header followed by a raw concat of the pre-packed frame bytes. msgpack is
a self-describing concatenative format, so ``<array header><obj1><obj2>…``
is a valid array — no re-encoding required.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any, Mapping, Sequence

import msgpack


def _pack_key_value(
    packer: msgpack.Packer, key: str, value: Any
) -> tuple[bytes, bytes]:
    return packer.pack(key), packer.pack(value)


def iter_serialized_trace_chunks(
    *,
    command_line_args,
    current_commit_sha,
    current_thread_id: str,
    meta: dict[str, Any],
    timestamp: float,
    trace_id: str,
    trace_name: str | None,
    threads: Mapping[str, Any],
    frames_by_thread: Mapping[str, Sequence[bytes]],
    root_trace_id: str | None = None,
) -> Iterator[bytes]:
    """Yield a complete trace without assembling one giant ``bytes`` object.

    Each yielded chunk is already valid msgpack. Callers that need the legacy
    contiguous representation can still join the iterator; persistence can
    write it directly and keep peak memory close to the resident frame data.
    """
    packer = msgpack.Packer(autoreset=True)
    prefix: list[bytes] = []

    map_len = 10 + (1 if root_trace_id is not None else 0)
    prefix.append(packer.pack_map_header(map_len))
    prefix.extend(_pack_key_value(packer, "command_line_args", command_line_args))
    prefix.extend(_pack_key_value(packer, "current_commit_sha", current_commit_sha))
    prefix.extend(_pack_key_value(packer, "current_thread_id", current_thread_id))
    prefix.extend(_pack_key_value(packer, "meta", meta))
    prefix.extend(_pack_key_value(packer, "timestamp", timestamp))
    prefix.extend(_pack_key_value(packer, "trace_id", trace_id))
    prefix.extend(_pack_key_value(packer, "trace_name", trace_name))
    if root_trace_id is not None:
        prefix.extend(_pack_key_value(packer, "root_trace_id", root_trace_id))
    prefix.extend(_pack_key_value(packer, "frames_of_interest", []))
    prefix.extend(_pack_key_value(packer, "frames", {}))

    prefix.append(packer.pack("threads"))
    prefix.append(packer.pack_map_header(len(threads)))
    thread_parts: list[tuple[list[bytes], Sequence[bytes]]] = []
    for thread_id, thread in threads.items():
        header = [packer.pack(thread_id)]

        has_frames = thread_id in frames_by_thread
        header.append(packer.pack_map_header(5 + (1 if has_frames else 0)))
        header.extend(_pack_key_value(packer, "name", thread.name))
        header.extend(_pack_key_value(packer, "ident", getattr(thread, "ident", None)))
        header.extend(
            _pack_key_value(packer, "native_id", getattr(thread, "native_id", None))
        )
        header.extend(_pack_key_value(packer, "daemon", thread.daemon))
        header.extend(_pack_key_value(packer, "is_alive", thread.is_alive()))

        if has_frames:
            frames = frames_by_thread[thread_id]
            header.append(packer.pack("frames"))
            header.append(packer.pack_array_header(len(frames)))
        else:
            frames = ()
        thread_parts.append((header, frames))

    def chunks() -> Iterator[bytes]:
        yield from prefix
        for header, frames in thread_parts:
            yield from header
            yield from frames

    return chunks()


def build_serialized_trace(
    *,
    command_line_args,
    current_commit_sha,
    current_thread_id: str,
    meta: dict[str, Any],
    timestamp: float,
    trace_id: str,
    trace_name: str | None,
    threads: Mapping[str, Any],
    frames_by_thread: Mapping[str, Sequence[bytes]],
    root_trace_id: str | None = None,
) -> bytes:
    """Build the legacy contiguous representation used by explicit callers."""

    return b"".join(
        iter_serialized_trace_chunks(
            command_line_args=command_line_args,
            current_commit_sha=current_commit_sha,
            current_thread_id=current_thread_id,
            meta=meta,
            timestamp=timestamp,
            trace_id=trace_id,
            trace_name=trace_name,
            threads=threads,
            frames_by_thread=frames_by_thread,
            root_trace_id=root_trace_id,
        )
    )
