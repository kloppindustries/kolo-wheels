from __future__ import annotations

from .profiler import enable, enabled

__all__ = ["enable", "enabled"]
