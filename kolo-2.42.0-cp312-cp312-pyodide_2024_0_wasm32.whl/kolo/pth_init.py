"""
Initialization module for automatic Kolo activation via .pth file.

This module is imported when KOLO environment variable is set to 1, true, or True,
typically via the kolo.pth file in site-packages.

Uses _AutoEnabled (not Enabled) for cleaner separation between:
- User-controlled activation (Enabled context manager)
- Automatic background activation (_AutoEnabled with atexit cleanup)
"""

import atexit
import os
import sys


def pth_init():
    """Initialize Kolo monitoring when called from .pth file."""
    try:
        # Check if disabled explicitly
        if os.environ.get("KOLO_DISABLE"):
            return

        # Check if enabled (accepts "1", "true", or "True")
        if os.environ.get("KOLO") not in ("1", "true", "True"):
            return

        # Import and activate Kolo using _AutoEnabled
        from kolo.core import _AutoEnabled

        # Create an _AutoEnabled instance with default config
        # IMPORTANT: Use save_in_thread=False to avoid segfaults during process exit.
        #
        # When save_in_thread=True, the trace is saved in a background thread. This works
        # fine in normal usage (middleware, context managers) because the main thread
        # continues execution and the background thread completes before process exit.
        #
        # However, in atexit handlers (like this one), the situation is different:
        # 1. Process is exiting, atexit handlers run
        # 2. __exit__() spawns background thread to save trace
        # 3. atexit handler returns
        # 4. Python interpreter begins shutdown (module cleanup, C extension teardown)
        # 5. Background thread is still running, trying to use msgpack C extension
        # 6. Race condition: thread accesses deallocated Python/C objects → SEGFAULT
        #
        # By using save_in_thread=False, we ensure the trace is saved synchronously
        # in the atexit handler before Python shutdown begins. The blocking on exit
        # is acceptable - users want their trace data saved reliably.
        auto_enabled = _AutoEnabled(
            config=None,
            source="KOLO=1",
            one_trace_per_test=False,
            save_in_thread=False,
            upload_token=None,
            db_path=None,
            name=None,
            inline=False,
            inline_returns=False,
        )

        # Activate monitoring and register cleanup only if activation succeeded
        if auto_enabled.activate():
            atexit.register(auto_enabled.cleanup)

    except Exception as e:
        # If anything goes wrong during initialization, print to stderr
        # but don't crash the Python process
        print(f"Kolo .pth initialization error: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc(file=sys.stderr)


pth_init()

# How to extend this:
# - Print location to compact trace on exit??
# - Don't call it compact trace, call it something else.
# - definitely needs to be a way to specify some config in the command line. KOLO_CFG=

# maybe just running `kolo` should show a preview of the latest trace -> yeah.
# and a list of the most recent traces..


# trace subcommands:
# Commands:
#   compact          Get a compact representation of a specific trace.
#   delete           Delete one or more traces stored by Kolo.
#   download         Download a trace from the Kolo dashboard
#   dump             Dump a trace from the Kolo database to stdout or a...
#   json-to-msgpack  Convert all legacy json traces to msgpack
#   list             Concisely list available traces, ordered by most...
#   list-queries     List all SQL queries in a trace.
#   load             Load a trace from a file into the Kolo database.
#   node             Get detailed information about a specific node in a...
#   pin              Pin a trace.
#   tree             Get the full JSON execution tree for a trace.
#   unpin            Unpin a previously pinned trace.
#   upload           Upload a trace to the Kolo dashboard

# kolo top level:
# Commands:
#   ci                         Subcommands for CI-related operations.
#   dbshell                    Open a sqlite3 shell to the Kolo database.
#   generate-test              Generate a test from a Kolo trace.
#   mcp                        Start the Kolo MCP server.
#   run                        Profile Python code using Kolo.
#   server                     Start a server to view traces.
#   store-django-model-schema  Store Django model info for test generation.
#   trace                      Subcommands for working with Kolo traces.


# and we should aim to give traces decent names automatically .... ?


# --- on trace viewing ---

# ⏺ Comprehensive Overview of Trace Naming in Kolo


#   ---
#   Python Code - Trace Naming Storage & Generation

#   1. Core Trace Name Property (src/kolo/trace.py:92-107)

#   The Trace class has a .name property with fallback logic:
#   1. First: Returns explicit trace_name from trace data if set
#   2. Second: Auto-generates from root node: "{first_node.name} and {N}
#   other calls"
#   3. Third: Falls back to trace ID


#   3. Auto-Naming Functions (src/kolo/utils.py)

#   extract_test_trace_name() (Lines 201-245)

#   - Searches first/last 3 frames for test start/end
#   - Returns: "{test_class}.{test_name}" or just "{test_name}"

#   extract_http_trace_name() (Lines 160-198)

#   - Searches first/last 3 frames for Django request/response
#   - Returns: "{status_code} {method} {path}" (e.g., "200 GET /api/users")


#   6. Database Storage (src/kolo/db.py:60-77)

#   - Important: trace_name is NOT a separate database column
#   - It's embedded within the msgpack blob in the msgpack column

#   ---
#   JS/VSCode Code - Trace Naming Display

#   1. TypeScript Trace Model (vscode/src/model.ts:69-106)

#   export interface Invocation {
#     trace_id: InvocationID;
#     trace_name?: string;  // Line 72 - Optional field
#     // ... other fields
#   }

#   2. ProcessedTrace Class (vscode/src/trace.ts:36-55)

#   Has a .name getter with similar fallback logic to Python:
#   1. First: Returns this.unprocessed.trace_name if set
#   2. Second: For simple served requests: "{method} {path_info}"
#   3. Third: For other traces: "{firstNode.name} and {N} other calls"
#   4. Fourth: Falls back to trace ID

#   Key difference from Python: Special handling for simple HTTP requests
#   that shows just the method and path (no "and N other calls").

#   3. UI Display Components

#   TraceListItem (vscode/src/webapp/src/components/TraceListItem.tsx:56)

#   <p>{data.name}</p>  // Displays the trace name from ProcessedTrace

#   TraceHeader (vscode/src/webapp/src/components/TraceHeader.tsx:22)

#   <div className="whitespace-nowrap">{trace.name}</div>

#   ProjectTracesPage
#   (vscode/src/webapp/src/app-dashboard/pages/ProjectTracesPage.tsx)

#   - Uses TraceListItem component to render traces
#   - Doesn't do any special display name formatting itself

#   4. Node-Level Names (vscode/src/node.ts:25)

#   Each ProcessedNode has a name field that comes from the execution tree
#   node. This is used to build the fallback trace name.

#   ---
#   Dashboard (Backend) - Limited Trace Name Support

#   Finding: The dashboard backend (dashboard/core/api.py) does NOT
#   currently extract or expose trace names in its API.

#   - No trace name field in API schemas
#   - Traces are stored but names aren't extracted from msgpack for display
#   - The dashboard likely would need updates to support displaying trace
#   names

#   ---
#   Summary: Where Trace Names Are Set

#   Explicitly Set:

#   1. User calls kolo.enable(name="My Trace")
#   2. Passed through Enabled → KoloProfiler/KoloMonitor
#   3. Stored in self.trace_name
#   4. Serialized into msgpack as "trace_name" field

#   Auto-Generated (if not explicitly set):

#   1. Test traces: Extracted from test start/end frames →
#   "TestClass.test_method"
#   2. HTTP traces: Extracted from Django request/response → "200 GET
#   /api/endpoint"
#   3. Fallback: Generated at display time from first node name

#   Display-Only (not stored in trace):

#   - VSCode extension creates special display for simple HTTP requests:
#   "{method} {path_info}"
#   - Python/CLI fallback: "{first_node.name} and {N} other calls"

#   ---
#   Key Insights for Default Naming Implementation

#   1. Already auto-named: Tests and HTTP requests already get decent names
#   automatically
#   2. Storage: Names are embedded in msgpack, not separate DB columns
#   3. Two naming layers:
#     - Storage layer: trace_name field (set during recording)
#     - Display layer: .name property (generated at access time with
#   fallbacks)
#   4. Gap: Non-HTTP, non-test traces only get auto-generated names from
#   node names, which might not be very descriptive

#   Would you like me to explore any specific area in more detail, or help
#   you design a better default naming strategy?
